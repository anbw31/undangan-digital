document.addEventListener("DOMContentLoaded", function () {
   document.body.style.overflow = 'hidden';

    const openButton = document.querySelector(".first-page .button");

    openButton.addEventListener("click", function (event) {
        event.preventDefault();

        document.body.style.overflow = 'auto';

        const secondPage = document.getElementById("second-page");
        secondPage.scrollIntoView({ behavior: 'smooth' });
    });

    const pages = document.querySelectorAll(".page");

    const observerOptions = {
        threshold: 0.2,
    };

    const observer = new IntersectionObserver(function (entries, observer) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add("visible");
            }
        });
    }, observerOptions);

    pages.forEach(page => {
        observer.observe(page);
    });
});

// Timer Countdown Script
var countDownDate = new Date("Sep 20, 2024 09:00:00").getTime();

var countdownFunction = setInterval(function() {
    var now = new Date().getTime();
    var distance = countDownDate - now;

    var days = Math.floor(distance / (1000 * 60 * 60 * 24));
    var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
    var seconds = Math.floor((distance % (1000 * 60)) / 1000);

    document.getElementById("days").innerHTML = days;
    document.getElementById("hours").innerHTML = hours;
    document.getElementById("minutes").innerHTML = minutes;
    document.getElementById("seconds").innerHTML = seconds;

    if (distance < 0) {
        clearInterval(countdownFunction);
        document.querySelector(".countdown").innerHTML = "EXPIRED";
    }
}, 1000);
